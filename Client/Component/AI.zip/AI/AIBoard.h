#pragma once
#include "../../Object/Object.h"

class AIBoard : public Object
{
public:
	AIBoard();
	virtual ~AIBoard();
public:
	virtual void Destroy() override;
};

class CharacterBoard : public AIBoard
{
public:
	CharacterBoard() {};
	virtual ~CharacterBoard() {};
public:
	Weak<class MovementComponent> _movement;
	Weak<class SpriteComponent> _sprite;
public:
	bool _isAlive = true;
	bool _isAttacking = false;
	bool _FlipRight = true;
public:
	std::string _idelAnimName	= "idle";
	std::string _moveAnimName	= "run";
	std::string _attackAnimName = "attack";
	std::string _deathAnimName	= "death";

};

class PlayerBoard : public AIBoard
{
public:
	PlayerBoard() {};
	virtual ~PlayerBoard() {};
public:
	bool _isMoveRight		= false;
	bool _isMoveLeft		= false;
	bool _isJump			= false;
	bool _isFall			= false;
	bool _isJumpAnimDone	= false;
	bool _isLookUp			= false;
	bool _isLookDown		= false;
	bool _isAttack			= false;
};