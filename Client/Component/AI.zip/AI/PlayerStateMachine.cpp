#include "pch.h"
#include "PlayerStateMachine.h"
#include "AIBoard.h"

void PlayerStateMachine::Init(Ptr<class AIComponent> owner)
{
	MachineBase::Init(owner);
	_interval = 0.f;

	auto board = CreateAIBoard<PlayerBoard>();
}

void PlayerStateMachine::Destroy()
{
}
