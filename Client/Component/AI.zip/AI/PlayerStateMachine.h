#pragma once
#include "MachineBase.h"

class PlayerStateMachine : public MachineBase
{
	friend class CharacterBoard;
public:
	PlayerStateMachine() {};
	virtual ~PlayerStateMachine() {};
public:
	virtual void Init(Ptr<class AIComponent> owner) override;
	virtual void Destroy() override;
};